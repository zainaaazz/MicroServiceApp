const UserCards = () => <h2>My Cards Page</h2>;
export default UserCards;
