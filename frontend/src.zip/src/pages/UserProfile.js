const UserProfile = () => <h2>My Profile Page</h2>;
export default UserProfile;
