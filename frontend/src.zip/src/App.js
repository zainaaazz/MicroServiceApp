import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import UserDashboard from './pages/UserDashboard';
import AdminDashboard from './pages/AdminDashboard';
import UserCards from './pages/UserCards';
import UserProfile from './pages/UserProfile';

function App() {
  return (
    <Router>
      <Routes>
        {/* 
        <Route path="/" element={<Navigate to="/user" replace />} />
        */}
        
        <Route path="/user" element={<UserDashboard />} />
   
        <Route path="/user/cards" element={<UserCards />} />
        <Route path="/user/profile" element={<UserProfile />} />


        <Route path="/admin" element={<AdminDashboard />} />
      </Routes>
    </Router>
  );
}

export default App;
